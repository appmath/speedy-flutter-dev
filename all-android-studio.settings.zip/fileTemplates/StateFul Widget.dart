import 'package:flutter/material.dart';

class ${className} extends StatefulWidget {

@override State<${className}State> createState() => _${className}StateState(); }

class _${className}State extends State<${className}> { @override Widget build(BuildContext
context) { return Container(); } }
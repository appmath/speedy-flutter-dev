import 'package:flutter/widgets.dart';

class $className with ChangeNotifier {
  
}

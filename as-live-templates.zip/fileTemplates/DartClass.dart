class $className {

}